package com.example.k2a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.k2a.core.Adapter.UserAdapter
import com.example.k2a.core.model.User
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.google.firebase.ktx.initialize

class MainActivity : AppCompatActivity() {

    private lateinit var firebaseAnalytics: FirebaseAnalytics


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Obtain the FirebaseAnalytics instance.
        firebaseAnalytics = Firebase.analytics

        firebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_ITEM, null)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        // create a layout manager
        recyclerView.layoutManager = LinearLayoutManager(this)

        // create array or list adapter
        val users = ArrayList<User>()

        // add elements to array
        users.add(
            User(
                "Sipho Ngobeni",
                "Software Engineer",
                "https://drive.google.com/file/d/1-7GNm9cH3PY1YGrmoYp_aiyMyt70wiwg/view?usp=sharing"
            )
        )
        users.add(
            User(
                "John",
                "Chemical Engineer",
                "https://drive.google.com/file/d/1-7GNm9cH3PY1YGrmoYp_aiyMyt70wiwg/view?usp=sharing"
            )
        )
        users.add(
            User(
                "kwakwa",
                "Test Engineer",
                "https://drive.google.com/file/d/1-7GNm9cH3PY1YGrmoYp_aiyMyt70wiwg/view?usp=sharing"
            )
        )

        // create an assign adapter
        val adapter = UserAdapter(users)
        recyclerView.adapter = adapter

        adapter.onItemClick = { user ->

            val intent = Intent(this, UserDetailsActivity::class.java)
            intent.putExtra("User", user)
            startActivity(intent)


        }


    }
}
