package com.example.k2a.core.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
class User (
    var name: String,
    val roleName: String,
    val profileUrl: String
): Parcelable