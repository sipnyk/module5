package com.example.k2a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.example.k2a.core.model.User
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_audio_play.*
import kotlinx.android.synthetic.main.activity_user_details.*

class UserDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_details)

        val textView = findViewById<TextView>(R.id.textView)
        val imageView = findViewById<ImageView>(R.id.profileImage)
        val button = findViewById<Button>(R.id.takePicture)
        val ShareProfile = findViewById<Button>(R.id.shareProfile)
        val AudioPlayActivity = findViewById<Button>(R.id.playSound)
        val adView= findViewById<AdView>(R.id.adView)



        //
        MobileAds.initialize(this)

        // get data
        val user = intent.getParcelableExtra<User>("User")

        // add user name to text view
        textView.text = user?.name

        Picasso.get().load(user?.profileUrl).into(imageView)

        button.setOnClickListener {
            val intent = Intent(this, TakePictureActivity::class.java)
            startActivity(intent)
        }

        shareProfile.setOnClickListener {
            if (user != null) {
                this.shareProfile(user)

            }
        }
    }

    fun shareProfile(user: User) {
        val sendIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, user.name)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, null)
        startActivity(shareIntent)

        playSound.setOnClickListener {
            val intent = Intent(this, AudioPlayActivity::class.java)
            startActivity(intent)

        }
    }
}




